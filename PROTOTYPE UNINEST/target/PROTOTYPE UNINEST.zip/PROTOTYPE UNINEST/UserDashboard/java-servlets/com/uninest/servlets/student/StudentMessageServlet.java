package com.uninest.servlets.student;

import com.uninest.utils.DatabaseConnection;
import com.uninest.utils.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * StudentMessageServlet - Sends student dashboard messages to admins for follow-up.
 * Path: /StudentMessageServlet
 */
@WebServlet("/StudentMessageServlet")
public class StudentMessageServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/createAccount/login.html");
            return;
        }

        String recipient = request.getParameter("recipient");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");

        if (!ValidationUtil.isRequired(subject) || !ValidationUtil.isRequired(message)) {
            redirect(request, response, "error", "Subject and message are required");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn == null) {
                redirect(request, response, "error", "Database connection is not available");
                return;
            }

            String body = "Student message to " + firstNonEmpty(recipient, "UniNest Support")
                    + ". Subject: " + subject.trim()
                    + ". Message: " + ValidationUtil.sanitizeXSS(message.trim());

            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO notifications (user_id, title, message, notification_type, action_url) "
                            + "SELECT user_id, 'Student dashboard message', ?, 'message_received', 'Messages.html' "
                            + "FROM users WHERE role = 'admin' AND status = 'active'");
            stmt.setString(1, body);
            stmt.executeUpdate();
            stmt.close();

            redirect(request, response, "success", "Message sent");
        } catch (SQLException e) {
            System.err.println("Database error in StudentMessageServlet: " + e.getMessage());
            e.printStackTrace();
            redirect(request, response, "error", "Could not send message");
        }
    }

    private String firstNonEmpty(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response,
                          String key, String message) throws IOException {
        response.sendRedirect(request.getContextPath() + "/UserDashboard/index.html?"
                + key
                + "="
                + java.net.URLEncoder.encode(message, "UTF-8"));
    }
}
