package com.uninest.servlets.student;

import com.uninest.utils.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * StudentRequestServlet - Starter endpoint for future viewing and booking requests.
 * Path: /StudentRequestServlet
 */
@WebServlet("/StudentRequestServlet")
public class StudentRequestServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/createAccount/login.html");
            return;
        }

        String listingId = request.getParameter("listingId");
        String requestType = request.getParameter("requestType");

        if (!ValidationUtil.isRequired(listingId) || !ValidationUtil.isRequired(requestType)) {
            redirect(request, response, "error", "Listing and request type are required");
            return;
        }

        session.setAttribute("lastStudentRequestListing", listingId);
        session.setAttribute("lastStudentRequestType", requestType);
        redirect(request, response, "success", "Request captured for backend booking integration");
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response,
                          String key, String message) throws IOException {
        response.sendRedirect(request.getContextPath() + "/UserDashboard/index.html?"
                + key
                + "="
                + java.net.URLEncoder.encode(message, "UTF-8"));
    }
}
