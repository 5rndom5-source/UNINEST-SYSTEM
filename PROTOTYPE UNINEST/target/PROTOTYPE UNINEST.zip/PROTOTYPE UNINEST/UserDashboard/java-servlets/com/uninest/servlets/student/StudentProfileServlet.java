package com.uninest.servlets.student;

import com.uninest.utils.DatabaseConnection;
import com.uninest.utils.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * StudentProfileServlet - Saves student profile contact details.
 * Path: /StudentProfileServlet
 */
@WebServlet("/StudentProfileServlet")
public class StudentProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/createAccount/login.html");
            return;
        }

        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String preferredArea = request.getParameter("preferredArea");
        String notes = request.getParameter("notes");

        if (!ValidationUtil.isRequired(fullName) || !ValidationUtil.isValidEmail(email)) {
            redirect(request, response, "error", "Name and email are required");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn == null) {
                redirect(request, response, "error", "Database connection is not available");
                return;
            }

            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?");
            stmt.setString(1, fullName.trim());
            stmt.setString(2, email.trim());
            stmt.setString(3, phone);
            stmt.setInt(4, (Integer) session.getAttribute("userId"));
            stmt.executeUpdate();
            stmt.close();

            session.setAttribute("studentName", fullName.trim());
            session.setAttribute("studentPreferredArea", preferredArea);
            session.setAttribute("studentNotes", notes);
            redirect(request, response, "success", "Profile saved");
        } catch (SQLException e) {
            System.err.println("Database error in StudentProfileServlet: " + e.getMessage());
            e.printStackTrace();
            redirect(request, response, "error", "Could not save profile");
        }
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response,
                          String key, String message) throws IOException {
        response.sendRedirect(request.getContextPath() + "/UserDashboard/index.html?"
                + key
                + "="
                + java.net.URLEncoder.encode(message, "UTF-8"));
    }
}
