const STORAGE_KEYS = {
  saved: "uninestStudentSavedListings",
  requests: "uninestStudentRequests",
  messages: "uninestStudentMessages",
  profile: "uninestStudentProfile"
};

const listings = [
  {
    id: "rondebosch-apartment",
    title: "Modern Apartments near campus",
    area: "Rondebosch",
    type: "Apartment",
    price: "R4,500 / month",
    image: "../HomePage/listing-rondebosch.png",
    tags: ["2 Beds", "Furnished", "Wifi"]
  },
  {
    id: "cbd-shared-room",
    title: "Cozy Room in Shared House",
    area: "Cape Town CBD",
    type: "Shared Room",
    price: "R2,800 / month",
    image: "../HomePage/listing-cbd-room.png",
    tags: ["1 Bed", "Shared", "Wifi"]
  },
  {
    id: "bellville-residence",
    title: "Student Residence",
    area: "Bellville",
    type: "Residence",
    price: "R3,200 / month",
    image: "../HomePage/listing-bellville-residence.png",
    tags: ["Security", "Wifi", "Parking"]
  }
];

const readStore = (key, fallback) => {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
};

const writeStore = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

const getSaved = () => readStore(STORAGE_KEYS.saved, []);
const getRequests = () => readStore(STORAGE_KEYS.requests, []);
const getMessages = () => readStore(STORAGE_KEYS.messages, []);
const getProfile = () => readStore(STORAGE_KEYS.profile, {});

const toast = (message) => {
  const item = document.getElementById("toast");
  item.textContent = message;
  item.classList.add("show");
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => item.classList.remove("show"), 2200);
};

const initialsFromName = (name) => {
  const parts = String(name || "Student Account").trim().split(/\s+/).slice(0, 2);
  return parts.map((part) => part[0]).join("").toUpperCase() || "ST";
};

const listingById = (id) => listings.find((listing) => listing.id === id);

const setView = (viewName) => {
  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.remove("active"));

  document.getElementById(`${viewName}View`)?.classList.add("active");
  document.querySelector(`.nav-item[data-view="${viewName}"]`)?.classList.add("active");
};

const makeListingCard = (listing, context = "browse") => {
  const saved = getSaved().includes(listing.id);
  const card = document.createElement("article");
  card.className = "listing-card";
  card.dataset.search = `${listing.title} ${listing.area} ${listing.type} ${listing.tags.join(" ")}`.toLowerCase();

  const image = document.createElement("div");
  image.className = "listing-image";
  const img = document.createElement("img");
  img.src = listing.image;
  img.alt = listing.title;
  image.appendChild(img);

  const body = document.createElement("div");
  body.className = "listing-body";

  const title = document.createElement("h3");
  title.textContent = listing.title;

  const price = document.createElement("p");
  price.className = "listing-price";
  price.textContent = listing.price;

  const meta = document.createElement("div");
  meta.className = "listing-meta";
  meta.innerHTML = `<span>${listing.area}</span><span>${listing.type}</span>`;

  const tags = document.createElement("div");
  tags.className = "listing-tags";
  listing.tags.forEach((tag) => {
    const span = document.createElement("span");
    span.textContent = tag;
    tags.appendChild(span);
  });

  const actions = document.createElement("div");
  actions.className = "card-actions";

  const saveButton = document.createElement("button");
  saveButton.className = "listing-action secondary";
  saveButton.type = "button";
  saveButton.textContent = saved ? "Saved" : "Save";
  saveButton.addEventListener("click", () => toggleSaved(listing.id));

  const requestButton = document.createElement("button");
  requestButton.className = "listing-action";
  requestButton.type = "button";
  requestButton.textContent = "Request Viewing";
  requestButton.addEventListener("click", () => createRequest(listing.id, "Viewing"));

  actions.append(saveButton, requestButton);

  if (context === "saved") {
    const removeButton = document.createElement("button");
    removeButton.className = "listing-action danger";
    removeButton.type = "button";
    removeButton.textContent = "Remove";
    removeButton.addEventListener("click", () => toggleSaved(listing.id));
    actions.appendChild(removeButton);
  }

  body.append(title, price, meta, tags, actions);
  card.append(image, body);
  return card;
};

const renderListings = () => {
  const overview = document.getElementById("overviewListings");
  const browse = document.getElementById("browseListings");
  const savedGrid = document.getElementById("savedListings");
  const area = document.getElementById("areaFilter")?.value || "all";
  const type = document.getElementById("typeFilter")?.value || "all";

  overview.innerHTML = "";
  listings.slice(0, 2).forEach((listing) => overview.appendChild(makeListingCard(listing)));

  const filtered = listings.filter((listing) => {
    const areaMatch = area === "all" || listing.area === area;
    const typeMatch = type === "all" || listing.type === type;
    return areaMatch && typeMatch;
  });

  browse.innerHTML = "";
  filtered.forEach((listing) => browse.appendChild(makeListingCard(listing)));

  const savedIds = getSaved();
  savedGrid.innerHTML = "";

  if (!savedIds.length) {
    savedGrid.innerHTML = '<div class="empty-state">No saved listings yet. Browse listings and save places you want to compare.</div>';
  } else {
    savedIds
      .map(listingById)
      .filter(Boolean)
      .forEach((listing) => savedGrid.appendChild(makeListingCard(listing, "saved")));
  }
};

const toggleSaved = (id) => {
  const saved = getSaved();
  const next = saved.includes(id) ? saved.filter((item) => item !== id) : [id, ...saved];
  writeStore(STORAGE_KEYS.saved, next);
  renderAll();
  toast(next.includes(id) ? "Listing saved." : "Listing removed.");
};

const createRequest = (listingId, type) => {
  const listing = listingById(listingId);
  if (!listing) return;

  const requests = getRequests();
  const request = {
    id: `request-${Date.now()}`,
    listingId,
    listingTitle: listing.title,
    area: listing.area,
    type,
    status: "Pending",
    createdAt: new Date().toLocaleDateString()
  };

  writeStore(STORAGE_KEYS.requests, [request, ...requests]);
  setView("requests");
  renderAll();
  toast("Request added to your dashboard.");
};

const renderRequests = () => {
  const tbody = document.getElementById("requestRows");
  const requests = getRequests();
  tbody.innerHTML = "";

  if (!requests.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No booking or viewing requests yet.</td></tr>';
    return;
  }

  requests.forEach((request) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td><strong>${request.listingTitle}</strong><br><small>${request.createdAt}</small></td>
      <td>${request.area}</td>
      <td>${request.type}</td>
      <td><span class="status-pill pending">${request.status}</span></td>
      <td><button class="listing-action danger" type="button" data-remove-request="${request.id}">Cancel</button></td>
    `;
    tbody.appendChild(row);
  });
};

const renderMessages = () => {
  const list = document.getElementById("messageList");
  const messages = getMessages();
  list.innerHTML = "";

  if (!messages.length) {
    list.innerHTML = '<div class="empty-state">No messages saved yet.</div>';
    return;
  }

  messages.forEach((message) => {
    const item = document.createElement("article");
    item.className = "message-item";
    item.innerHTML = `
      <strong>${message.subject}</strong>
      <span>${message.recipient} • ${message.createdAt}</span>
      <p>${message.body}</p>
    `;
    list.appendChild(item);
  });
};

const renderProfile = () => {
  const profile = getProfile();
  const name = profile.name || "Student Account";
  const email = profile.email || "No email saved yet";
  const phone = profile.phone || "No phone saved yet";
  const initials = initialsFromName(name);

  document.getElementById("profileNameLabel").textContent = name;
  document.getElementById("profileInitials").textContent = initials;
  document.getElementById("profileAvatarLarge").textContent = initials;
  document.getElementById("profileCardName").textContent = name;
  document.getElementById("profileCardEmail").textContent = email;
  document.getElementById("profileCardPhone").textContent = phone;

  document.getElementById("studentName").value = profile.name || "";
  document.getElementById("studentEmail").value = profile.email || "";
  document.getElementById("studentPhone").value = profile.phone || "";
  document.getElementById("studentArea").value = profile.area || "";
  document.getElementById("studentNotes").value = profile.notes || "";
};

const updateCounts = () => {
  document.getElementById("savedCount").textContent = getSaved().length;
  document.getElementById("requestCount").textContent = getRequests().length;
  document.getElementById("messageCount").textContent = getMessages().length;
};

const renderAll = () => {
  renderListings();
  renderRequests();
  renderMessages();
  renderProfile();
  updateCounts();
  applySearch();
};

const applySearch = () => {
  const term = document.getElementById("globalSearch").value.trim().toLowerCase();
  document.querySelectorAll(".listing-card").forEach((card) => {
    card.style.display = !term || card.dataset.search.includes(term) ? "" : "none";
  });
};

document.addEventListener("click", (event) => {
  const viewButton = event.target.closest("[data-view]");
  if (viewButton) setView(viewButton.dataset.view);

  const removeRequest = event.target.closest("[data-remove-request]");
  if (removeRequest) {
    const requests = getRequests().filter((request) => request.id !== removeRequest.dataset.removeRequest);
    writeStore(STORAGE_KEYS.requests, requests);
    renderAll();
    toast("Request cancelled.");
  }
});

document.getElementById("areaFilter").addEventListener("change", renderListings);
document.getElementById("typeFilter").addEventListener("change", renderListings);
document.getElementById("globalSearch").addEventListener("input", applySearch);

document.getElementById("messageForm").addEventListener("submit", (event) => {
  if (event.currentTarget.getAttribute("action")) return;

  event.preventDefault();
  const message = {
    id: `message-${Date.now()}`,
    recipient: document.getElementById("messageRecipient").value,
    subject: document.getElementById("messageSubject").value.trim(),
    body: document.getElementById("messageBody").value.trim(),
    createdAt: new Date().toLocaleDateString()
  };

  writeStore(STORAGE_KEYS.messages, [message, ...getMessages()]);
  event.target.reset();
  renderAll();
  toast("Message saved.");
});

document.getElementById("profileForm").addEventListener("submit", (event) => {
  if (event.currentTarget.getAttribute("action")) return;

  event.preventDefault();
  const profile = {
    name: document.getElementById("studentName").value.trim(),
    email: document.getElementById("studentEmail").value.trim(),
    phone: document.getElementById("studentPhone").value.trim(),
    area: document.getElementById("studentArea").value,
    notes: document.getElementById("studentNotes").value.trim()
  };

  writeStore(STORAGE_KEYS.profile, profile);
  renderAll();
  toast("Profile saved.");
});

renderAll();
