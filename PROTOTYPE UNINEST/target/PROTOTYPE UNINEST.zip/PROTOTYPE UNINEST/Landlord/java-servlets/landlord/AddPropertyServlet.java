package com.uninest.servlets.landlord;

import com.uninest.utils.DatabaseConnection;
import com.uninest.utils.ValidationUtil;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/LandlordAddPropertyServlet")
@MultipartConfig(maxFileSize = 5242880, maxRequestSize = 52428800)
public class AddPropertyServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("propertyTitle");
        String description = request.getParameter("description");
        String location = request.getParameter("location");
        String price = request.getParameter("price");
        String[] amenities = request.getParameterValues("amenities");

        if (!ValidationUtil.isRequired(title)
                || !ValidationUtil.isRequired(description)
                || !ValidationUtil.isRequired(location)
                || !ValidationUtil.isValidPrice(price)) {
            response.sendRedirect("Landlord/listings.html?error=missing");
            return;
        }

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("landlordId") == null) {
            response.sendRedirect("Landlord/login.html?error=session");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn == null) {
                response.sendRedirect("Landlord/listings.html?error=db");
                return;
            }

            int roomId = insertRoom(
                    conn,
                    (Integer) session.getAttribute("landlordId"),
                    title.trim(),
                    description.trim(),
                    location.trim(),
                    new BigDecimal(price),
                    amenities);

            insertAmenities(conn, roomId, amenities);
            saveImages(request, conn, roomId);

            session.setAttribute("listingStatus", "Pending Approval");
            response.sendRedirect("Landlord/listings.html?status=pending");
        } catch (SQLException e) {
            System.err.println("Database error in Landlord AddPropertyServlet: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect("Landlord/listings.html?error=save");
        }
    }

    private int insertRoom(Connection conn, int landlordId, String title, String description,
                           String location, BigDecimal price, String[] amenities)
            throws SQLException {
        String query = "INSERT INTO rooms "
                + "(landlord_id, room_number, room_type, location, price, capacity, description, "
                + "availability_status, furnishing, approval_status) "
                + "VALUES (?, ?, 'apartment', ?, ?, 1, ?, 'available', ?, 'pending')";

        PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setInt(1, landlordId);
        stmt.setString(2, title);
        stmt.setString(3, location);
        stmt.setBigDecimal(4, price);
        stmt.setString(5, description);
        stmt.setString(6, hasAmenity(amenities, "Furnished") ? "fully_furnished" : "unfurnished");
        stmt.executeUpdate();

        ResultSet keys = stmt.getGeneratedKeys();
        int roomId = 0;
        if (keys.next()) {
            roomId = keys.getInt(1);
        }
        stmt.close();
        return roomId;
    }

    private void insertAmenities(Connection conn, int roomId, String[] amenities) throws SQLException {
        if (amenities == null || roomId == 0) {
            return;
        }

        for (int i = 0; i < amenities.length; i++) {
            String amenity = amenities[i];
            if ("Furnished".equalsIgnoreCase(amenity)) {
                continue;
            }

            Integer amenityId = findAmenityId(conn, amenity);
            if (amenityId == null) {
                continue;
            }

            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT IGNORE INTO room_amenities (room_id, amenity_id) VALUES (?, ?)");
            stmt.setInt(1, roomId);
            stmt.setInt(2, amenityId);
            stmt.executeUpdate();
            stmt.close();
        }
    }

    private Integer findAmenityId(Connection conn, String amenityName) throws SQLException {
        PreparedStatement stmt = conn.prepareStatement(
                "SELECT amenity_id FROM amenities WHERE amenity_name = ?");
        stmt.setString(1, amenityName);
        ResultSet rs = stmt.executeQuery();

        Integer amenityId = null;
        if (rs.next()) {
            amenityId = rs.getInt("amenity_id");
        }
        stmt.close();
        return amenityId;
    }

    private void saveImages(HttpServletRequest request, Connection conn, int roomId)
            throws IOException, ServletException, SQLException {
        String uploadRoot = getServletContext().getRealPath("/uploads/properties");
        File uploadDir = new File(uploadRoot);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        int displayOrder = 0;
        for (Part part : request.getParts()) {
            if (!"photos".equals(part.getName()) || part.getSize() == 0) {
                continue;
            }

            String fileName = System.currentTimeMillis() + "_" + part.getSubmittedFileName();
            part.write(new File(uploadDir, fileName).getAbsolutePath());
            insertImage(conn, roomId, "/uploads/properties/" + fileName, displayOrder == 0, displayOrder);
            displayOrder++;
        }
    }

    private void insertImage(Connection conn, int roomId, String imageUrl,
                             boolean primary, int displayOrder) throws SQLException {
        PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO room_images (room_id, image_url, is_primary, display_order) VALUES (?, ?, ?, ?)");
        stmt.setInt(1, roomId);
        stmt.setString(2, imageUrl);
        stmt.setBoolean(3, primary);
        stmt.setInt(4, displayOrder);
        stmt.executeUpdate();
        stmt.close();
    }

    private boolean hasAmenity(String[] amenities, String target) {
        if (amenities == null) {
            return false;
        }
        for (int i = 0; i < amenities.length; i++) {
            if (target.equalsIgnoreCase(amenities[i])) {
                return true;
            }
        }
        return false;
    }
}
