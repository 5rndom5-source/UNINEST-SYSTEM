const LISTINGS_KEY = "uninestLandlordListings";

const showBanner = (id, message) => {
  const banner = document.getElementById(id);
  if (!banner) return;
  banner.textContent = message;
  banner.classList.add("show");
};

const getListings = () => {
  try {
    return JSON.parse(localStorage.getItem(LISTINGS_KEY) || "[]");
  } catch {
    return [];
  }
};

const saveListings = (listings) => {
  localStorage.setItem(LISTINGS_KEY, JSON.stringify(listings));
};

const formatPrice = (value) => {
  const amount = Number(value || 0);
  return amount > 0 ? `R${amount.toLocaleString()}/month` : "Price not set";
};

const readFirstImage = (input) => {
  const file = input?.files?.[0];
  if (!file) return Promise.resolve("");

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => resolve("");
    reader.readAsDataURL(file);
  });
};

const makeListingCard = (listing) => {
  const card = document.createElement("article");
  card.className = "classic-property-card";
  card.dataset.id = listing.id;

  const title = document.createElement("h3");
  title.textContent = listing.title;

  const body = document.createElement("div");
  body.className = "classic-property-body";

  const imageBox = document.createElement("div");
  imageBox.className = "classic-card-image";
  if (listing.image) {
    const img = document.createElement("img");
    img.src = listing.image;
    img.alt = listing.title;
    imageBox.appendChild(img);
  } else {
    imageBox.textContent = "Image";
  }

  const details = document.createElement("div");
  details.className = "classic-card-details";

  const location = document.createElement("p");
  location.textContent = listing.location;

  const price = document.createElement("p");
  price.textContent = formatPrice(listing.price);

  const status = document.createElement("span");
  status.className = "classic-status pending";
  status.textContent = "Pending";

  const actions = document.createElement("div");
  actions.className = "classic-card-actions";

  const edit = document.createElement("button");
  edit.type = "button";
  edit.className = "btn edit-btn";
  edit.textContent = "Edit";

  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "btn btn-red delete-btn";
  remove.textContent = "Delete";

  actions.append(edit, remove);
  details.append(location, price, status, actions);
  body.append(imageBox, details);
  card.append(title, body);

  return card;
};

const renderListings = () => {
  const grid = document.getElementById("propertyGrid");
  if (!grid) return;

  const listings = getListings();
  grid.innerHTML = "";

  if (!listings.length) {
    const empty = document.createElement("article");
    empty.className = "classic-empty-listing";
    empty.id = "emptyListingState";
    empty.textContent = "No property listings have been added yet.";
    grid.appendChild(empty);
    return;
  }

  listings.forEach((listing) => grid.appendChild(makeListingCard(listing)));
};

const handleListingForm = () => {
  const form = document.getElementById("propertyForm");
  if (!form) return;

  const fileInput = document.getElementById("propertyPhotos");
  const uploadName = document.getElementById("uploadName");
  const uploadPreview = document.getElementById("uploadPreview");
  const status = document.getElementById("listingStatus");

  renderListings();

  fileInput?.addEventListener("change", async () => {
    const count = fileInput.files?.length || 0;
    if (uploadName) {
      uploadName.textContent =
        count === 1 ? fileInput.files[0].name : `${count} images selected`;
    }

    if (uploadPreview) {
      const preview = await readFirstImage(fileInput);
      uploadPreview.src = preview;
      uploadPreview.classList.toggle("hidden", !preview);
    }
  });

  form.addEventListener("reset", () => {
    form.removeAttribute("data-editing-id");
    if (uploadName) uploadName.textContent = "No image selected";
    if (uploadPreview) uploadPreview.classList.add("hidden");
    if (status) status.textContent = "Pending Approval";
  });

  form.addEventListener("submit", async (event) => {
    if (form.getAttribute("action")) return;

    event.preventDefault();

    const editingId = form.getAttribute("data-editing-id");
    const currentListings = getListings();
    const existing = currentListings.find((item) => item.id === editingId);
    const image = (await readFirstImage(fileInput)) || existing?.image || "";

    const amenities = Array.from(form.querySelectorAll('input[name="amenities"]:checked'))
      .map((item) => item.value);

    const listing = {
      id: editingId || `listing-${Date.now()}`,
      title: document.getElementById("propertyTitle").value.trim(),
      description: document.getElementById("propertyDescription").value.trim(),
      location: document.getElementById("propertyLocation").value,
      price: document.getElementById("propertyPrice").value,
      amenities,
      image,
      status: "Pending",
      updatedAt: new Date().toISOString()
    };

    if (!listing.title || !listing.location || !listing.price) return;

    const nextListings = editingId
      ? currentListings.map((item) => (item.id === editingId ? listing : item))
      : [listing, ...currentListings];

    saveListings(nextListings);
    renderListings();

    form.reset();
    form.removeAttribute("data-editing-id");
    if (uploadName) uploadName.textContent = "No image selected";
    if (uploadPreview) uploadPreview.classList.add("hidden");
    if (status) {
      status.textContent = editingId ? "Listing Updated - Pending Approval" : "Listing Submitted - Pending Approval";
    }
  });

  document.getElementById("propertyGrid")?.addEventListener("click", (event) => {
    const card = event.target.closest(".classic-property-card");
    if (!card) return;

    const listings = getListings();
    const listing = listings.find((item) => item.id === card.dataset.id);
    if (!listing) return;

    if (event.target.closest(".delete-btn")) {
      saveListings(listings.filter((item) => item.id !== listing.id));
      renderListings();
      return;
    }

    if (event.target.closest(".edit-btn")) {
      document.getElementById("propertyTitle").value = listing.title;
      document.getElementById("propertyDescription").value = listing.description || "";
      document.getElementById("propertyLocation").value = listing.location;
      document.getElementById("propertyPrice").value = listing.price;
      form.setAttribute("data-editing-id", listing.id);
      if (status) status.textContent = "Editing Listing - Pending Approval";
      form.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
};

const hydrateContactListing = () => {
  const preview = document.getElementById("contactPropertyPreview");
  if (!preview) return;

  const latest = getListings()[0];
  if (!latest) return;

  document.getElementById("contactPropertyTitle").textContent = latest.title;
  const propertyInput = document.getElementById("contactPropertyInput");
  if (propertyInput) propertyInput.value = latest.title;
  document.getElementById("contactPropertyLocation").textContent = latest.location;
  document.getElementById("contactPropertyPrice").textContent = formatPrice(latest.price);
  const contactStatus = document.getElementById("contactPropertyStatus");
  contactStatus.textContent = "Available";
  contactStatus.classList.remove("neutral");

  const imageBox = document.getElementById("contactPropertyImage");
  imageBox.innerHTML = "";
  if (latest.image) {
    const img = document.createElement("img");
    img.src = latest.image;
    img.alt = latest.title;
    imageBox.appendChild(img);
  } else {
    imageBox.textContent = "Image";
  }
};

document.getElementById("landlordLoginForm")?.addEventListener("submit", (event) => {
  if (event.currentTarget.getAttribute("action")) return;

  event.preventDefault();
  window.location.href = "index.html";
});

document.getElementById("contactLandlordForm")?.addEventListener("submit", (event) => {
  if (event.currentTarget.getAttribute("action")) return;

  event.preventDefault();
  event.target.reset();
  document.getElementById("messageSuccess")?.classList.add("show");
});

document.querySelectorAll("[data-pending-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const bannerId = form.querySelector(".status-banner")?.id || form.getAttribute("data-banner") || "";
    showBanner(bannerId, "Database connection required before this information can be saved.");
  });
});

handleListingForm();
hydrateContactListing();
