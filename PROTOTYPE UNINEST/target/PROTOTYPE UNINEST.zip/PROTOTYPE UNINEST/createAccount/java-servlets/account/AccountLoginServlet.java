package com.uninest.servlets.account;

import com.uninest.utils.DatabaseConnection;
import com.uninest.utils.PasswordUtil;
import com.uninest.utils.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * AccountLoginServlet - Role-aware login for the shared createAccount/login.html page.
 * Path: /AccountLoginServlet
 */
@WebServlet("/AccountLoginServlet")
public class AccountLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        if (!ValidationUtil.isValidEmail(email)
                || !ValidationUtil.isRequired(password)
                || !isValidRole(role)) {
            redirect(request, response, "createAccount/login.html", "error", "Invalid login details");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            if (conn == null) {
                redirect(request, response, "createAccount/login.html", "error", "Database connection is not available");
                return;
            }

            String query = "SELECT user_id, full_name, password, role, status "
                    + "FROM users WHERE email = ? AND role = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email.trim());
            stmt.setString(2, role.trim());
            ResultSet rs = stmt.executeQuery();

            if (!rs.next() || !PasswordUtil.verifyPassword(password, rs.getString("password"))) {
                stmt.close();
                redirect(request, response, "createAccount/login.html", "error", "Invalid email or password");
                return;
            }

            if ("suspended".equalsIgnoreCase(rs.getString("status"))
                    || "inactive".equalsIgnoreCase(rs.getString("status"))) {
                stmt.close();
                redirect(request, response, "createAccount/login.html", "error", "This account is not active");
                return;
            }

            HttpSession session = request.getSession();
            int userId = rs.getInt("user_id");
            String fullName = rs.getString("full_name");
            session.setAttribute("userId", userId);
            session.setAttribute("fullName", fullName);
            session.setAttribute("role", role);

            if ("admin".equals(role)) {
                session.setAttribute("adminId", userId);
            } else if ("landlord".equals(role)) {
                session.setAttribute("landlordName", fullName);
            } else {
                session.setAttribute("studentName", fullName);
            }

            stmt.close();
            response.sendRedirect(request.getContextPath() + "/" + destinationFor(role));
        } catch (SQLException e) {
            System.err.println("Database error in AccountLoginServlet: " + e.getMessage());
            e.printStackTrace();
            redirect(request, response, "createAccount/login.html", "error", "Could not sign in");
        }
    }

    private boolean isValidRole(String role) {
        return "student".equals(role) || "landlord".equals(role) || "admin".equals(role);
    }

    private String destinationFor(String role) {
        if ("landlord".equals(role)) return "Landlord/index.html";
        if ("admin".equals(role)) return "Admin/web/jsp/Dashboard.html";
        return "UserDashboard/index.html";
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response, String page,
                          String key, String message) throws IOException {
        response.sendRedirect(request.getContextPath() + "/" + page
                + "?"
                + key
                + "="
                + java.net.URLEncoder.encode(message, "UTF-8"));
    }
}
