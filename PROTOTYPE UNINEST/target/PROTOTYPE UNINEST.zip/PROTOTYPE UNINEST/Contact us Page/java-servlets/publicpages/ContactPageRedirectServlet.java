package com.uninest.servlets.publicpages;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * ContactPageRedirectServlet - Keeps the mockup folder connected to the live
 * HomePage contact screen.
 * Path: /ContactPageRedirectServlet
 */
@WebServlet("/ContactPageRedirectServlet")
public class ContactPageRedirectServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/HomePage/contact.html");
    }
}
