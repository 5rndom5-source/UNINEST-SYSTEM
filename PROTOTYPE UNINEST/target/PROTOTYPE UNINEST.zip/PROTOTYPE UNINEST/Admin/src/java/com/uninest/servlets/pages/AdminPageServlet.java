package com.uninest.servlets.pages;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * AdminPageServlet - Optional servlet entry points for Admin pages that also
 * exist as HTML files under web/jsp.
 */
@WebServlet({
        "/DashboardServlet",
        "/AddPropertyPageServlet",
        "/BookingDetailsServlet",
        "/BookingRequestsPageServlet",
        "/DownloadReceiptServlet",
        "/EditPropertyPageServlet",
        "/EnquiriesPageServlet",
        "/ForgotPasswordPageServlet",
        "/LoginPageServlet",
        "/LogoutPageServlet",
        "/MaintenancePageServlet",
        "/MessagesPageServlet",
        "/MyPropertiesPageServlet",
        "/PaymentsPageServlet",
        "/ProfilePageServlet",
        "/RegisterPageServlet",
        "/ViewBookingServlet",
        "/ViewMaintenanceServlet",
        "/ViewPaymentServlet",
        "/ViewPropertyServlet"
})
public class AdminPageServlet extends HttpServlet {

    private static final Map<String, String> PAGES = new HashMap<String, String>();

    static {
        PAGES.put("/DashboardServlet", "Dashboard.html");
        PAGES.put("/AddPropertyPageServlet", "AddProperty.html");
        PAGES.put("/BookingDetailsServlet", "BookingDetails.html");
        PAGES.put("/BookingRequestsPageServlet", "BookingRequests.html");
        PAGES.put("/DownloadReceiptServlet", "DownloadReceipt.html");
        PAGES.put("/EditPropertyPageServlet", "EditProperty.html");
        PAGES.put("/EnquiriesPageServlet", "Enquiries.html");
        PAGES.put("/ForgotPasswordPageServlet", "ForgotPassword.html");
        PAGES.put("/LoginPageServlet", "Login.html");
        PAGES.put("/LogoutPageServlet", "Logout.html");
        PAGES.put("/MaintenancePageServlet", "Maintenance.html");
        PAGES.put("/MessagesPageServlet", "Messages.html");
        PAGES.put("/MyPropertiesPageServlet", "MyProperties.html");
        PAGES.put("/PaymentsPageServlet", "Payments.html");
        PAGES.put("/ProfilePageServlet", "Profile.html");
        PAGES.put("/RegisterPageServlet", "Register.html");
        PAGES.put("/ViewBookingServlet", "ViewBooking.html");
        PAGES.put("/ViewMaintenanceServlet", "ViewMaintenance.html");
        PAGES.put("/ViewPaymentServlet", "ViewPayment.html");
        PAGES.put("/ViewPropertyServlet", "ViewProperty.html");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String page = PAGES.get(request.getServletPath());
        if (page == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        request.getRequestDispatcher("/jsp/" + page).forward(request, response);
    }
}
