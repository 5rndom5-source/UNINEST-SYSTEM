package com.uninest.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseConnection - Singleton pattern for database connectivity
 * Manages MySQL connection pooling and resource management
 */
public class DatabaseConnection {
    
    // Database configuration - CHANGE THESE VALUES TO YOUR DATABASE
    private static final String DB_URL = "jdbc:mysql://localhost:3306/uninest";
    private static final String DB_USER = "root";  // Change to your MySQL username
    private static final String DB_PASSWORD = "";  // Change to your MySQL password
    private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
    
    private static DatabaseConnection instance = null;
    private Connection connection = null;
    
    /**
     * Private constructor to prevent instantiation
     */
    private DatabaseConnection() {
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
        }
    }
    
    /**
     * Get singleton instance of DatabaseConnection
     */
    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    /**
     * Get a new database connection
     */
    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                System.out.println("✓ Database connection established successfully");
            }
        } catch (SQLException e) {
            System.err.println("✗ Database connection failed!");
            e.printStackTrace();
        }
        return connection;
    }
    
    /**
     * Close database connection
     */
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("✓ Database connection closed");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error closing database connection!");
            e.printStackTrace();
        }
    }
    
    /**
     * Test database connection
     */
    public static void testConnection() {
        try {
            Connection conn = getInstance().getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println("✓ Database connection test PASSED");
            } else {
                System.out.println("✗ Database connection test FAILED");
            }
        } catch (SQLException e) {
            System.err.println("✗ Connection test error: " + e.getMessage());
        }
    }
}
